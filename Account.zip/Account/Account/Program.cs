﻿namespace Account
{
    internal class Account
    {
        public string Name { get; set; }
        private decimal balance;
        public Account(string account, decimal initialBalance)
        {
            Name = account;
            balance = initialBalance;
        }

        public decimal Balance
        {
            get
            {
                return balance;
            }
            private set
            {
                if (value > 0.0m)
                {
                    balance = value;
                }
            }
        }
        public void Deposit(decimal depositAmount)
        {
            if (depositAmount > 0.0m)
            {
                Balance = depositAmount + Balance;
            }
        }
        public void withdraw(decimal amount)
        {
            if (amount < balance)
            {
                Balance = balance - amount;
            }
        }
    }
}