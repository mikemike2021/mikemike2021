public class ThreadFun1 {
    public static void main(String[] args) {//throws InterruptedException{
        Task1 task1 = new Task1("sunshine", 250);
        Task1 task2 = new Task1("clouds", 250);
        Task1 task3 = new Task1("mules", 500);

        Thread thread1 = new Thread(task1);
        Thread thread2 = new Thread(task2);
        Thread thread3 = new Thread(task3);


        thread1.start();
        thread2.start();
        thread3.start();


     /*  try {
            thread1.join();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/



        System.out.println("ALL DONE!");
    }
}

class Task1 implements Runnable{
    String word;
    int number;

    public Task1(String word, int number){
        this.word = word;
        this.number = number;
    }

    @Override
    public void run(){
        for (int i = 0; i < number; i++){
            if (word.equals("sunshine")) {
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println(word);
        }
        System.out.println(word + " Task is FINISHED!\n");
    }


}
